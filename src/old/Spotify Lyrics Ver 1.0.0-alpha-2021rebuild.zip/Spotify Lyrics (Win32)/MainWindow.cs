﻿using Microsoft.VisualBasic;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Spotify_Lyrics
{
    public partial class MainWindow : Form
    {
        public struct Lyric
        {
            public string lyricText;
            public int time;
            public string originText;
        }

        public MainWindow()
        {
            InitializeComponent();
        }
        private void MainWindow_Load(object sender, EventArgs e)
        {
            Text = Text + " Ver " + AppVer.Major + "." + AppVer.Minor + "." + AppVer.Build + SpecialVersion;
        }

        Version AppVer = Assembly.GetExecutingAssembly().GetName().Version; string SpecialVersion = " Alpha"; // " Beta" or Nothing
        public string NowSong = "", NowArtist = "", titleInfo = "";
        public string LastSong = "", LastArtist = ""; public string OriginLyricText = "";
        public Lyric[] nowLyric = new Lyric[1000]; public int totalLines = 0, nowPlayingLine = -1;
        public string sourceUrl = @"http://e.wxriw.top:8008/res/";
        public int nowPlayStartTime = 0; public int slowDownTime = 350; public bool excludeBlankLine = true;
        public int displayLines = 5; //Lines above & below

        private void button1_Click(object sender, EventArgs e)
        {
            NameSplit(GetSpotifyTrackInfo());
            labelSong.Text = NowSong;
            labelArt.Text = NowArtist;
            string webLyric = GetWebClient(sourceUrl + NowArtist + @"/" + NowSong + ".lrc");
            if (webLyric == "Lyric Not Found")
            {
                textBox1.Text = "This song's lyric isn't on our server yet.\n";
            }
            else
            {
                textBox1.Text = webLyric;
            }
        }

        private void timerStartTime_Tick(object sender, EventArgs e)
        {
            //Display
            labelTime.Text = (Environment.TickCount - nowPlayStartTime).ToString();

            //Check if Change_Line needed
            if (Environment.TickCount - nowPlayStartTime >= nowLyric[nowPlayingLine + 1].time)
            {
                changeLine();
            }
        }

        public void changeLine()
        {
            if (nowPlayingLine == totalLines) return;

            //Clean
            labelPlayedLyrics.Text = "";
            labelPlaying.Text = "";
            labelPrePlay.Text = "";

            //Played
            if (nowPlayingLine >= 0)
            {
                labelPlayedLyrics.Text = nowLyric[nowPlayingLine].lyricText;
                for (int i = nowPlayingLine - 1; i > nowPlayingLine - displayLines && i >= 0; i--)
                {
                    labelPlayedLyrics.Text = nowLyric[i].lyricText + Environment.NewLine + labelPlayedLyrics.Text;
                }
            }

            //Now Playing
            labelPlaying.Text = nowLyric[nowPlayingLine + 1].lyricText;

            //Preparing
            for (int i = nowPlayingLine + 2; i <= nowPlayingLine + displayLines + 1 && i <= totalLines; i++)
            {
                labelPrePlay.Text += nowLyric[i].lyricText + Environment.NewLine;
            }


            nowPlayingLine++;
        }

        private void timerRefreshSong_Tick(object sender, EventArgs e)
        {
            NameSplit(GetSpotifyTrackInfo());
            if (labelSong.Text != NowSong || labelArt.Text != NowArtist)
            {
                LastSong = labelSong.Text;
                LastArtist = labelArt.Text;
                if (titleInfo == "Spotify is not running!" || titleInfo == "No track is playing")
                {
                    labelSong.Text = titleInfo;
                    labelArt.Text = "";
                    timerStartTime.Enabled = false;
                }
                else
                {
                    labelSong.Text = NowSong;
                    labelArt.Text = NowArtist;

                    //Clean
                    labelPlayedLyrics.Text = "";
                    labelPlaying.Text = "";
                    labelPrePlay.Text = "";

                    timerStartTime.Enabled = false;
                    nowPlayStartTime = System.Environment.TickCount + slowDownTime;
                    timerStartTime.Enabled = true;

                    refreshLyric();
                }
            }
        }

        public void refreshLyric()
        {
            string webLyric = GetWebClient(sourceUrl + NowArtist + @"/" + NowSong + ".lrc");
            if (webLyric == "Lyric Not Found")
            {
                textBox1.Text = "This song's lyric isn't on our server yet.\n";
            }
            else
            {
                OriginLyricText = webLyric;
                textBox1.Text = webLyric;
                processLyric();
            }
        }
        public bool processLyric()
        {
            //Process the line problem & put into Struct
            int lines = 0;
            string[] arr = OriginLyricText.Split('[');
            for (int i = 0; i < arr.Length; i++)
            {
                string str = "[" + arr[i];
                int t = CheckTime(str);
                if (t == -1) continue;
                nowLyric[lines] = new Lyric();
                nowLyric[lines].time = t;
                nowLyric[lines].originText = str;
                nowLyric[lines].lyricText = Strings.Mid(str, str.IndexOf(']') + 2).Replace("\n", "").Replace("\r", "");
                if (nowLyric[lines].lyricText == "" && excludeBlankLine) lines--;
                lines++;
            }
            totalLines = lines;
            nowPlayingLine = -1;

            textBox1.Text = "";
            for (int i = 0; i < lines; i++)
            {
                textBox1.Text += nowLyric[i].time.ToString("000000") + "  " + nowLyric[i].lyricText + Environment.NewLine;
            }


            return true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBoxNeteaseDownID.Text != "" && textBoxNeteaseDownID.Text.Length > 7)
            {
                WebBrowser webBrowser = new WebBrowser();
                webBrowser.Navigate(@"http://music.163.com/song/media/outer/url?id=" + textBoxNeteaseDownID.Text + ".mp3");
            }
        }

        public int CheckTime(string str)
        {
            if (str.Length < 9) return -1;
            if (str[1] >= '0' && str[1] <= '9' && str[2] >= '0' && str[2] <= '9' && str[3] == ':' && str[6] == '.')
            {
                int t = 0;
                try
                {
                    t += (str[1] - 48) * 600000 + (str[2] - 48) * 60000;
                }
                catch { }
                try
                {
                    t += (str[4] - 48) * 10000 + (str[5] - 48) * 1000;
                }
                catch { }
                try
                {
                    if (str[9] >= '0' && str[9] <= '9')
                    {
                        t += (str[7] - 48) * 100 + (str[8] - 48) * 10 + (str[9] - 48);
                    }
                    else
                    {
                        if (str[9] == ']')
                        {
                            t += (str[7] - 48) * 100 + (str[8] - 48) * 10;
                        }
                    }
                }
                catch { }
                return t;
            }
            else
            {
                return -1;
            }
        }

        public string GetSpotifyTrackInfo()
        {
            var proc = Process.GetProcessesByName("Spotify").FirstOrDefault(p => !string.IsNullOrWhiteSpace(p.MainWindowTitle));

            if (proc == null)
            {
                return "Spotify is not running!";
            }

            if (string.Equals(proc.MainWindowTitle, "Spotify", StringComparison.InvariantCultureIgnoreCase) || string.Equals(proc.MainWindowTitle, "Spotify Free", StringComparison.InvariantCultureIgnoreCase))
            {
                return "No track is playing";
            }

            return proc.MainWindowTitle;
        }

        public void NameSplit(string nameStr)
        {
            titleInfo = nameStr;
            if (nameStr == "Spotify is not running!" || nameStr == "No track is playing")
            {
                NowArtist = "null";
                NowSong = "null";
                return;
            }
            try
            {
                string[] arr = Regex.Split(nameStr, " - ", RegexOptions.IgnoreCase);
                NowArtist = arr[0];
                NowSong = arr[1];
            }
            catch { }
            return;
        }

        private string GetWebClient(string url)
        {
            string strHTML = "";
            WebClient myWebClient = new WebClient();
            Stream myStream = myWebClient.OpenRead(url);
            StreamReader sr = new StreamReader(myStream, System.Text.Encoding.GetEncoding("utf-8"));
            strHTML = sr.ReadToEnd();
            myStream.Close();
            return strHTML;
        }
    }
}

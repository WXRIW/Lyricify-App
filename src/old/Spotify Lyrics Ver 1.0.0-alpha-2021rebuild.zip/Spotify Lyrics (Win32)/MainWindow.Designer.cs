﻿namespace Spotify_Lyrics
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelSong = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.labelArt = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.timerStartTime = new System.Windows.Forms.Timer(this.components);
            this.timerRefreshSong = new System.Windows.Forms.Timer(this.components);
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.labelTime = new System.Windows.Forms.Label();
            this.labelPlayedLyrics = new System.Windows.Forms.Label();
            this.labelPlaying = new System.Windows.Forms.Label();
            this.labelPrePlay = new System.Windows.Forms.Label();
            this.lyricsPanel = new System.Windows.Forms.TableLayoutPanel();
            this.textBoxNeteaseDownID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonNeteaseDown = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lyricsPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelSong
            // 
            this.labelSong.AutoSize = true;
            this.labelSong.Location = new System.Drawing.Point(141, 24);
            this.labelSong.Name = "labelSong";
            this.labelSong.Size = new System.Drawing.Size(84, 36);
            this.labelSong.TabIndex = 0;
            this.labelSong.Text = "Song";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(602, 76);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(168, 45);
            this.button1.TabIndex = 1;
            this.button1.Text = "Get";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // labelArt
            // 
            this.labelArt.AutoSize = true;
            this.labelArt.Location = new System.Drawing.Point(141, 81);
            this.labelArt.Name = "labelArt";
            this.labelArt.Size = new System.Drawing.Size(86, 36);
            this.labelArt.TabIndex = 2;
            this.labelArt.Text = "Artist";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft YaHei", 10F);
            this.textBox1.Location = new System.Drawing.Point(780, 12);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(317, 531);
            this.textBox1.TabIndex = 3;
            // 
            // timerStartTime
            // 
            this.timerStartTime.Interval = 50;
            this.timerStartTime.Tick += new System.EventHandler(this.timerStartTime_Tick);
            // 
            // timerRefreshSong
            // 
            this.timerRefreshSong.Enabled = true;
            this.timerRefreshSong.Interval = 50;
            this.timerRefreshSong.Tick += new System.EventHandler(this.timerRefreshSong_Tick);
            // 
            // labelTime
            // 
            this.labelTime.AutoSize = true;
            this.labelTime.Location = new System.Drawing.Point(596, 24);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(31, 36);
            this.labelTime.TabIndex = 4;
            this.labelTime.Text = "0";
            // 
            // labelPlayedLyrics
            // 
            this.labelPlayedLyrics.AutoSize = true;
            this.labelPlayedLyrics.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelPlayedLyrics.Font = new System.Drawing.Font("Microsoft YaHei", 15F);
            this.labelPlayedLyrics.Location = new System.Drawing.Point(3, 0);
            this.labelPlayedLyrics.Name = "labelPlayedLyrics";
            this.labelPlayedLyrics.Size = new System.Drawing.Size(750, 164);
            this.labelPlayedLyrics.TabIndex = 5;
            this.labelPlayedLyrics.Text = "Played";
            this.labelPlayedLyrics.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // labelPlaying
            // 
            this.labelPlaying.AutoSize = true;
            this.labelPlaying.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelPlaying.Font = new System.Drawing.Font("Microsoft YaHei", 19F, System.Drawing.FontStyle.Bold);
            this.labelPlaying.Location = new System.Drawing.Point(3, 164);
            this.labelPlaying.Name = "labelPlaying";
            this.labelPlaying.Size = new System.Drawing.Size(750, 78);
            this.labelPlaying.TabIndex = 6;
            this.labelPlaying.Text = "Playing";
            this.labelPlaying.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelPrePlay
            // 
            this.labelPrePlay.AutoSize = true;
            this.labelPrePlay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelPrePlay.Font = new System.Drawing.Font("Microsoft YaHei", 15F);
            this.labelPrePlay.Location = new System.Drawing.Point(3, 242);
            this.labelPrePlay.Name = "labelPrePlay";
            this.labelPrePlay.Size = new System.Drawing.Size(750, 165);
            this.labelPrePlay.TabIndex = 7;
            this.labelPrePlay.Text = "Preparing";
            this.labelPrePlay.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lyricsPanel
            // 
            this.lyricsPanel.ColumnCount = 1;
            this.lyricsPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.lyricsPanel.Controls.Add(this.labelPlayedLyrics, 0, 0);
            this.lyricsPanel.Controls.Add(this.labelPrePlay, 0, 2);
            this.lyricsPanel.Controls.Add(this.labelPlaying, 0, 1);
            this.lyricsPanel.Location = new System.Drawing.Point(18, 136);
            this.lyricsPanel.Name = "lyricsPanel";
            this.lyricsPanel.RowCount = 3;
            this.lyricsPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.32258F));
            this.lyricsPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.35484F));
            this.lyricsPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.32258F));
            this.lyricsPanel.Size = new System.Drawing.Size(756, 407);
            this.lyricsPanel.TabIndex = 8;
            // 
            // textBoxNeteaseDownID
            // 
            this.textBoxNeteaseDownID.Font = new System.Drawing.Font("Microsoft YaHei", 14F);
            this.textBoxNeteaseDownID.Location = new System.Drawing.Point(1121, 123);
            this.textBoxNeteaseDownID.Name = "textBoxNeteaseDownID";
            this.textBoxNeteaseDownID.Size = new System.Drawing.Size(176, 38);
            this.textBoxNeteaseDownID.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 14F);
            this.label1.Location = new System.Drawing.Point(1115, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 31);
            this.label1.TabIndex = 10;
            this.label1.Text = "网易云音乐下载";
            // 
            // buttonNeteaseDown
            // 
            this.buttonNeteaseDown.Font = new System.Drawing.Font("Microsoft YaHei", 14F);
            this.buttonNeteaseDown.Location = new System.Drawing.Point(1121, 177);
            this.buttonNeteaseDown.Name = "buttonNeteaseDown";
            this.buttonNeteaseDown.Size = new System.Drawing.Size(176, 42);
            this.buttonNeteaseDown.TabIndex = 11;
            this.buttonNeteaseDown.Text = "下载";
            this.buttonNeteaseDown.UseVisualStyleBackColor = true;
            this.buttonNeteaseDown.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 14F);
            this.label2.Location = new System.Drawing.Point(1115, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 31);
            this.label2.TabIndex = 12;
            this.label2.Text = "歌曲ID：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(20, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 37);
            this.label3.TabIndex = 13;
            this.label3.Text = "Artist";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(21, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 37);
            this.label4.TabIndex = 14;
            this.label4.Text = "Song";
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1109, 555);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonNeteaseDown);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxNeteaseDownID);
            this.Controls.Add(this.lyricsPanel);
            this.Controls.Add(this.labelTime);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.labelArt);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.labelSong);
            this.Font = new System.Drawing.Font("Microsoft YaHei", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "MainWindow";
            this.Text = "Spotify Lyrics by WXRIW - 2021 Rebuild";
            this.Load += new System.EventHandler(this.MainWindow_Load);
            this.lyricsPanel.ResumeLayout(false);
            this.lyricsPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelSong;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label labelArt;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Timer timerStartTime;
        private System.Windows.Forms.Timer timerRefreshSong;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Label labelTime;
        private System.Windows.Forms.Label labelPlayedLyrics;
        private System.Windows.Forms.Label labelPlaying;
        private System.Windows.Forms.Label labelPrePlay;
        private System.Windows.Forms.TableLayoutPanel lyricsPanel;
        private System.Windows.Forms.TextBox textBoxNeteaseDownID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonNeteaseDown;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}